

def median_of_three(arr, low, high):
    mid = (low + high) // 2
    a = arr[low]
    b = arr[mid]
    c = arr[high]
    
    if a <= b <= c or c <= b <= a:
        return mid
    if b <= a <= c or c <= a <= b:
        return low
    return high

def partition(arr, low, high):
    # Use median-of-three for better pivot selection
    pivot_index = median_of_three(arr, low, high)
    arr[pivot_index], arr[high] = arr[high], arr[pivot_index]
    pivot = arr[high]
    
    i = low - 1
    
    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    
    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1

def quick_sort_helper(arr, low, high):
    # Use iterative approach to avoid recursion depth issues
    stack = []
    stack.append((low, high))
    
    while stack:
        low, high = stack.pop()
        if low < high:
            pi = partition(arr, low, high)
            # Push the larger subarray first to limit stack size
            if pi - low > high - pi:
                stack.append((low, pi - 1))
                stack.append((pi + 1, high))
            else:
                stack.append((pi + 1, high))
                stack.append((low, pi - 1))

def quick_sort(arr):
    if len(arr) > 0:
        quick_sort_helper(arr, 0, len(arr) - 1)

