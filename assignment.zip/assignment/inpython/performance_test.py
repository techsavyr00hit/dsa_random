import time
import os

# Import sorting algorithms
from bubble_sort import bubble_sort
from quick_sort import quick_sort
from merge_sort import merge_sort
from selection_sort import selection_sort
from insertion_sort import insertion_sort
from heap_sort import heap_sort
from bucket_sort import bucket_sort
from radix_sort import radix_sort

def get_test_case_name(test_type):
    names = {
        "ascending": "Ascending",
        "descending": "Descending",
        "random": "Random",
        "mixed": "Mixed",
        "partially_ordered": "Partially Ordered"
    }
    return names.get(test_type, "Unknown")

def read_test_case_from_file(filename):
    """Read test case from file and return as list of integers"""
    with open(filename, 'r') as f:
        return [int(line.strip()) for line in f.readlines() if line.strip()]

def run_sorting_test(algorithm, test_case_data):
    # Make a copy for sorting (to avoid measuring generation time)
    arr_copy = test_case_data.copy()

    # Time the sorting algorithm
    start_time = time.time()

    if algorithm == "BubbleSort":
        bubble_sort(arr_copy)
    elif algorithm == "QuickSort":
        quick_sort(arr_copy)
    elif algorithm == "MergeSort":
        merge_sort(arr_copy)
    elif algorithm == "SelectionSort":
        selection_sort(arr_copy)
    elif algorithm == "InsertionSort":
        insertion_sort(arr_copy)
    elif algorithm == "HeapSort":
        heap_sort(arr_copy)
    elif algorithm == "BucketSort":
        bucket_sort(arr_copy)
    elif algorithm == "RadixSort":
        radix_sort(arr_copy)

    end_time = time.time()

    # Convert to microseconds
    time_elapsed = (end_time - start_time) * 1000000

    return time_elapsed

def main():
    algorithms = [
        "BubbleSort", "QuickSort", "MergeSort", "SelectionSort",
        "InsertionSort", "HeapSort", "BucketSort", "RadixSort"
    ]

    # Define test case types and sizes
    test_types = ["ascending", "descending", "random", "mixed", "partially_ordered"]
    sizes = [100, 1000, 10000]

    # Use relative path to testcase folder
    testcase_dir = "testcase"

    try:
        for algo in algorithms:
            print(f"\n=== Testing {algo} ===")

            for size in sizes:
                for test_type in test_types:
                    # Construct filename using absolute path
                    filename = os.path.join(testcase_dir, f"{test_type}_{size}.txt")

                    # Check if file exists
                    if not os.path.exists(filename):
                        continue

                    # Read test case
                    test_data = read_test_case_from_file(filename)

                    # Run sorting test
                    time_elapsed = run_sorting_test(algo, test_data)

                    # Print results to terminal in CSV format
                    print(f"{algo},{size},{get_test_case_name(test_type)},{time_elapsed:.6f}")

        print("Performance testing complete! All results saved to performance_results.csv")

    except Exception as e:
        print(f"Error writing to CSV file: {e}")

if __name__ == "__main__":
    main()
