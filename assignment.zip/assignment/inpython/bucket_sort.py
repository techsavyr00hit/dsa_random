

def bucket_sort(arr):
    n = len(arr)
    if n <= 0:
        return
    
    # Create buckets
    buckets = [[] for _ in range(n)]
    
    # Put array elements in different buckets
    for num in arr:
        bucket_index = int(num / (max(arr) + 1) * n)
        buckets[bucket_index].append(num)
    
    # Sort individual buckets
    for bucket in buckets:
        bucket.sort()
    
    # Concatenate all buckets into arr[]
    index = 0
    for bucket in buckets:
        for num in bucket:
            arr[index] = num
            index += 1

