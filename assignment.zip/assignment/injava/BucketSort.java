import java.util.ArrayList;
import java.util.Collections;

public class BucketSort {
    
    public static void bucketSort(int[] arr) {
        int n = arr.length;
        if (n <= 0) {
            return;
        }
        
        // Create buckets
        @SuppressWarnings("unchecked")
        ArrayList<Integer>[] buckets = new ArrayList[n];
        
        // Initialize buckets
        for (int i = 0; i < n; i++) {
            buckets[i] = new ArrayList<>();
        }
        
        // Put array elements in different buckets
        int maxVal = arr[0];
        for (int num : arr) {
            if (num > maxVal) {
                maxVal = num;
            }
        }
        maxVal = Math.max(maxVal, 1); // Ensure we don't divide by zero
        
        for (int i = 0; i < n; i++) {
            int bucketIndex = (int) ((arr[i] / (double) (maxVal + 1)) * n);
            // Ensure bucketIndex is within bounds
            bucketIndex = Math.min(Math.max(bucketIndex, 0), n - 1);
            buckets[bucketIndex].add(arr[i]);
        }
        
        // Sort individual buckets
        for (int i = 0; i < n; i++) {
            Collections.sort(buckets[i]);
        }
        
        // Concatenate all buckets into arr[]
        int index = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < buckets[i].size(); j++) {
                arr[index++] = buckets[i].get(j);
            }
        }
    }
    
    public static void main(String[] args) {
        // Main method kept for compatibility, but actual testing is done through PerformanceTest.java
    }
}