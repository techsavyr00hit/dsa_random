public class RadixSort {
    
    public static void radixSort(int[] arr) {
        int n = arr.length;
        
        // Find the maximum number to know number of digits
        int m = getMax(arr, n);
        
        // Do counting sort for every digit
        for (int exp = 1; m / exp > 0; exp *= 10) {
            countSort(arr, n, exp);
        }
    }
    
    public static int getMax(int[] arr, int n) {
        int mx = arr[0];
        for (int i = 1; i < n; i++) {
            if (arr[i] > mx) {
                mx = arr[i];
            }
        }
        return mx;
    }
    
    public static void countSort(int[] arr, int n, int exp) {
        int[] output = new int[n];
        int[] count = new int[10];
        
        // Store count of occurrences in count[]
        for (int i = 0; i < n; i++) {
            int digit = Math.abs((arr[i] / exp) % 10); // Use absolute value to handle negative numbers
            count[digit]++;
        }
        
        // Change count[i] so that count[i] now contains
        // actual position of this digit in output[]
        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }
        
        // Build the output array
        for (int i = n - 1; i >= 0; i--) {
            int digit = Math.abs((arr[i] / exp) % 10); // Use absolute value to handle negative numbers
            output[count[digit] - 1] = arr[i];
            count[digit]--;
        }
        
        // Copy the output array to arr[], so that arr[] now
        // contains sorted numbers according to current digit
        for (int i = 0; i < n; i++) {
            arr[i] = output[i];
        }
    }
    
    public static void main(String[] args) {
        // Main method kept for compatibility, but actual testing is done through PerformanceTest.java
    }
}