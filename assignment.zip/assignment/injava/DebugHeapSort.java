public class DebugHeapSort {
    public static void main(String[] args) {
        // Test with a small array that needs sorting
        int[] testArray = {5, 3, 8, 1, 2};
        
        System.out.print("Before: ");
        for (int num : testArray) {
            System.out.print(num + " ");
        }
        System.out.println();
        
        // Time the sort
        long start = System.nanoTime();
        HeapSort.heapSort(testArray);
        long end = System.nanoTime();
        
        System.out.print("After: ");
        for (int num : testArray) {
            System.out.print(num + " ");
        }
        System.out.println();
        
        long duration = (end - start) / 1000; // Convert to microseconds
        System.out.println("Time taken: " + duration + " µs");
        
        // Test with a larger array
        int[] largeArray = new int[1000];
        for (int i = 0; i < largeArray.length; i++) {
            largeArray[i] = largeArray.length - i; // Reverse order
        }
        
        start = System.nanoTime();
        HeapSort.heapSort(largeArray);
        end = System.nanoTime();
        
        duration = (end - start) / 1000;
        System.out.println("Time for 1000 elements: " + duration + " µs");
        
        // Verify it's actually sorted
        boolean sorted = true;
        for (int i = 1; i < largeArray.length; i++) {
            if (largeArray[i] < largeArray[i-1]) {
                sorted = false;
                break;
            }
        }
        System.out.println("Array is sorted: " + sorted);
    }
}