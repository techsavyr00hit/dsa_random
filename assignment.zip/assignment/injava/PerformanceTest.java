

public class PerformanceTest {
    
    public static void main(String[] args) {
        String[] algorithms = {
            "BubbleSort", "QuickSort", "MergeSort", "SelectionSort", 
            "InsertionSort", "HeapSort", "BucketSort", "RadixSort"
        };
        
        int[] sizes = {100, 1000, 10000};
        String[] testCaseTypes = {"random", "partially_ordered", "mixed", "ascending", "descending"};
        
        for (String algo : algorithms) {
            System.out.println("Testing " + algo + "...");
            
            for (int size : sizes) {
                for (String testCaseType : testCaseTypes) {
                    long timeElapsed = runSortingTest(algo, size, testCaseType);
                    
                    // Output results in the format: algo,size,type,time
                    System.out.println(algo + "," + size + "," + testCaseType + "," + timeElapsed);
                }
            }
        }
        
        System.out.println("\nPerformance testing complete!");
    }
    
    private static int getOptimalRuns(int size) {
        // Adjust number of runs based on array size to balance accuracy and performance
        if (size <= 100) {
            return 100; // Many runs for small arrays (fast to execute)
        } else if (size <= 1000) {
            return 50;  // Medium runs for medium arrays
        } else {
            return 10;  // Few runs for large arrays (slow to execute)
        }
    }
    
    private static long runSortingTest(String algorithm, int size, String testCaseType) {
        // Read test case from file
        String filename = "testcase/" + testCaseType + "_" + size + ".txt";
        int[] arr = readTestCaseFile(filename);
        
        if (arr.length == 0) {
            System.err.println("Failed to read test case: " + filename);
            return -1;
        }
        
        // JVM warm-up runs (not measured)
        for (int i = 0; i < 10; i++) {
            int[] warmupCopy = new int[arr.length];
            System.arraycopy(arr, 0, warmupCopy, 0, arr.length);
            runSortingAlgorithm(algorithm, warmupCopy);
        }
        
        // Determine number of runs based on array size (larger arrays = fewer runs)
        int numRuns = getOptimalRuns(size);
        long totalTime = 0;
        
        for (int run = 0; run < numRuns; run++) {
            // Make a fresh copy for each run
            int[] arrCopy = new int[arr.length];
            System.arraycopy(arr, 0, arrCopy, 0, arr.length);
            
            // Time this single run
            long start = System.nanoTime();
            runSortingAlgorithm(algorithm, arrCopy);
            long end = System.nanoTime();
            
            totalTime += (end - start);
        }
        
        // Return average time in microseconds
        return totalTime / (numRuns * 1000);
    }
    
    private static void runSortingAlgorithm(String algorithm, int[] arr) {
        switch (algorithm) {
            case "BubbleSort":
                BubbleSort.bubbleSort(arr);
                break;
            case "QuickSort":
                QuickSort.quickSort(arr, 0, arr.length - 1);
                break;
            case "MergeSort":
                MergeSort.mergeSort(arr, 0, arr.length - 1);
                break;
            case "SelectionSort":
                SelectionSort.selectionSort(arr);
                break;
            case "InsertionSort":
                InsertionSort.insertionSort(arr);
                break;
            case "HeapSort":
                HeapSort.heapSort(arr);
                break;
            case "BucketSort":
                BucketSort.bucketSort(arr);
                break;
            case "RadixSort":
                RadixSort.radixSort(arr);
                break;
        }
    }
    
    private static int[] readTestCaseFile(String filename) {
        try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader(filename))) {
            java.util.ArrayList<Integer> list = new java.util.ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                list.add(Integer.parseInt(line.trim()));
            }
            
            int[] arr = new int[list.size()];
            for (int i = 0; i < list.size(); i++) {
                arr[i] = list.get(i);
            }
            return arr;
        } catch (Exception e) {
            System.err.println("Error reading test case file " + filename + ": " + e.getMessage());
            return new int[0];
        }
    }
    

}