#include <iostream>
#include <vector>
#include <chrono>
#include <fstream>
#include <algorithm>

using namespace std;
using namespace std::chrono;

// Function to read integers from a file
vector<int> readInput(const string& filename) {
    vector<int> arr;
    ifstream file(filename);
    int num;
    while (file >> num) {
        arr.push_back(num);
    }
    return arr;
}

// Bubble Sort
void bubbleSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n-1; ++i) {
        for (int j = 0; j < n-i-1; ++j) {
            if (arr[j] > arr[j+1]) {
                swap(arr[j], arr[j+1]);
            }
        }
    }
}

// Insertion Sort
void insertionSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 1; i < n; ++i) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            --j;
        }
        arr[j + 1] = key;
    }
}

// Selection Sort
void selectionSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; ++i) {
        int minIndex = i;
        for (int j = i + 1; j < n; ++j) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        swap(arr[i], arr[minIndex]);
    }
}

// Merge Sort
void merge(vector<int>& arr, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;
    vector<int> L(n1), R(n2);
    for (int i = 0; i < n1; ++i) L[i] = arr[left + i];
    for (int j = 0; j < n2; ++j) R[j] = arr[mid + 1 + j];
    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) arr[k++] = L[i++];
        else arr[k++] = R[j++];
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
}

void mergeSort(vector<int>& arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }
}

// Quick Sort
int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j < high; ++j) {
        if (arr[j] < pivot) swap(arr[++i], arr[j]);
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;
}

void quickSort(vector<int>& arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Heap Sort
void heapify(vector<int>& arr, int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    if (left < n && arr[left] > arr[largest]) largest = left;
    if (right < n && arr[right] > arr[largest]) largest = right;
    if (largest != i) {
        swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}

void heapSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = n / 2 - 1; i >= 0; --i) heapify(arr, n, i);
    for (int i = n - 1; i > 0; --i) {
        swap(arr[0], arr[i]);
        heapify(arr, i, 0);
    }
}

// Radix Sort
int getMax(const vector<int>& arr) {
    return *max_element(arr.begin(), arr.end());
}

void countSort(vector<int>& arr, int exp) {
    int n = arr.size();
    vector<int> output(n);
    vector<int> count(10, 0);
    for (int i = 0; i < n; ++i) count[(arr[i] / exp) % 10]++;
    for (int i = 1; i < 10; ++i) count[i] += count[i - 1];
    for (int i = n - 1; i >= 0; --i) {
        output[count[(arr[i] / exp) % 10] - 1] = arr[i];
        count[(arr[i] / exp) % 10]--;
    }
    for (int i = 0; i < n; ++i) arr[i] = output[i];
}

void radixSort(vector<int>& arr) {
    int max = getMax(arr);
    for (int exp = 1; max / exp > 0; exp *= 10) {
        countSort(arr, exp);
    }
}

// Function to get test case name
string getTestCaseName(const string& test_type) {
    if (test_type == "ascending") return "ascending";
    if (test_type == "descending") return "descending";
    if (test_type == "random") return "random";
    if (test_type == "mixed") return "mixed";
    if (test_type == "partially_ordered") return "partially_ordered";
    return "unknown";
}

int main() {
    // Define algorithms
    vector<pair<string, void(*)(vector<int>&)>> algorithms = {
        {"bubble_sort", bubbleSort},
        {"insertion_sort", insertionSort},
        {"selection_sort", selectionSort},
        {"merge_sort", [](vector<int>& arr) { mergeSort(arr, 0, arr.size() - 1); }},
        {"quick_sort", [](vector<int>& arr) { quickSort(arr, 0, arr.size() - 1); }},
        {"heap_sort", heapSort},
        {"radix_sort", radixSort}
    };

    // Define test case types and sizes
    vector<string> test_types = {"ascending", "descending", "random", "mixed", "partially_ordered"};
    vector<int> sizes = {100, 1000, 10000};

    // Output header
    cout << "(algo,size,type,time)" << endl;

    // Run tests
    for (const auto& algo : algorithms) {
        string algo_name = algo.first;
        auto sort_func = algo.second;

        for (int size : sizes) {
            for (const string& test_type : test_types) {
                string filename = "testcase/" + test_type + "_" + to_string(size) + ".txt";

                // Check if file exists
                ifstream file(filename);
                if (!file.good()) {
                    continue;
                }

                // Read test data
                vector<int> test_data = readInput(filename);

                // Make a copy for sorting
                vector<int> arr_copy = test_data;

                // Measure time
                auto start = high_resolution_clock::now();
                sort_func(arr_copy);
                auto end = high_resolution_clock::now();
                auto duration = duration_cast<microseconds>(end - start);

                // Output results
                cout << algo_name << "," << size << "," << test_type << "," << duration.count() << endl;
            }
        }
    }

    return 0;
}
