#include <iostream>
#include <vector>
#include <algorithm>

void bucketSort(std::vector<float>& arr) {
    int n = arr.size();
    std::vector<std::vector<float>> buckets(n);

    // Distribute elements into buckets
    for (float num : arr) {
        int bucketIndex = static_cast<int>(num * n);
        buckets[bucketIndex].push_back(num);
    }

    // Sort individual buckets
    for (auto& bucket : buckets) {
        std::sort(bucket.begin(), bucket.end());
    }

    // Concatenate all buckets into arr[]
    int index = 0;
    for (auto& bucket : buckets) {
        for (float num : bucket) {
            arr[index++] = num;
        }
    }
}

int main() {
    std::vector<float> arr = {0.897, 0.565, 0.656, 0.1234, 0.665, 0.3434};
    bucketSort(arr);
    for (float num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    return 0;
}